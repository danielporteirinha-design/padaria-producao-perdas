import type { VercelRequest, VercelResponse } from "@vercel/node";
import * as admin from "firebase-admin";

if (!admin.apps.length) {
  const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
  if (serviceAccountJson) {
    try {
      const serviceAccount = JSON.parse(serviceAccountJson);
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
      });
    } catch (e) {
      console.error("Erro ao parsear credencial do Firebase:", e);
    }
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Método não permitido" });
  }

  const { lojaId, desfecho, motivo } = req.body;
  if (!lojaId || !desfecho) {
    return res.status(400).json({ error: "Dados incompletos" });
  }

  try {
    const db = admin.firestore();
    const snapshot = await db
      .app && db.collection("dispositivos").where("lojaId", "==", lojaId).get();

    if (!snapshot || snapshot.empty) {
      return res.status(200).json({ enviados: 0, mensagem: "Nenhum aparelho registrado para esta loja." });
    }

    const tokens: string[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      if (data.token) tokens.push(data.token);
    });

    if (tokens.length === 0) {
      return res.status(200).json({ enviados: 0 });
    }

    const titulo = desfecho === "confirmado" ? "Suprimentos Confirmados! ✅" : "Suprimentos Não Enviados ❌";
    const corpo = desfecho === "confirmado" 
      ? "A matriz confirmou e separou a sua lista de suprimentos." 
      : `A matriz não pôde enviar os suprimentos: ${motivo ?? "sem motivo informado"}`;

    const mensagem = {
      tokens,
      notification: {
        title: titulo,
        body: corpo,
      },
      data: {
        tipo: "tocar-aviso",
        url: "/?aba=suprimentos",
      },
    };

    const resposta = await admin.messaging().sendEachForMulticast(mensagem);
    return res.status(200).json({ enviados: resposta.successCount });
  } catch (erro) {
    console.error("Erro ao enviar notificação de suprimentos:", erro);
    return res.status(500).json({ error: "Erro interno ao enviar notificação" });
  }
}