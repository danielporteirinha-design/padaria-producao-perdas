/**
 * src/lib/avisarFiliais.ts
 * ---------------------------------------------------------------
 * Funções de disparo de notificações push para as filiais e matriz (ago/2026).
 */

export class ErroAviso extends Error {
  constructor(mensagem: string) {
    super(mensagem);
    this.name = "ErroAviso";
  }
}

export async function testarAvisos(
  destino: "matriz" | "filial"
): Promise<{ enviados: number; registrados: number; motivos?: string[] }> {
  try {
    const resposta = await fetch("/api/testar-aviso", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ destino }),
    });
    if (!resposta.ok) throw new Error("Servidor indisponível");
    return await resposta.json();
  } catch (erro) {
    console.warn("Falha ao testar aviso:", erro);
    throw new ErroAviso("Não foi possível enviar o aviso de teste.");
  }
}

export async function avisarFiliais(
  nomeProduto: string,
  codigoPdv: number,
  vezesHoje: number,
  quantidade?: number
): Promise<{ enviados: number; registrados: number; motivos?: string[] }> {
  try {
    const resposta = await fetch("/api/notificar-fornada", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nomeProduto, codigoPdv, vezesHoje, quantidade }),
    });
    if (!resposta.ok) throw new Error("Servidor indisponível");
    return await resposta.json();
  } catch (erro) {
    console.warn("Falha ao notificar filiais:", erro);
    throw new ErroAviso("Não foi possível enviar o aviso automático.");
  }
}

export async function avisarMatriz(
  nomeProduto: string,
  codigoPdv: number,
  quantidade: number,
  variedades: number
): Promise<void> {
  try {
    await fetch("/api/notificar-matriz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nomeProduto, codigoPdv, quantidade, variedades }),
    });
  } catch (erro) {
    console.warn("Falha ao notificar matriz:", erro);
  }
}

export async function avisarListaEnviada(variedades: number): Promise<void> {
  try {
    await fetch("/api/notificar-matriz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tipo: "lista", variedades }),
    });
  } catch (erro) {
    console.warn("Falha ao notificar matriz sobre lista:", erro);
  }
}

export async function avisarListaDeSuprimentos(variedades: number): Promise<void> {
  try {
    await fetch("/api/notificar-matriz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tipo: "suprimentos", variedades }),
    });
  } catch (erro) {
    console.warn("Falha ao notificar matriz sobre suprimentos:", erro);
  }
}

export async function avisarDesfechoReposicao(
  lojaId: string,
  nomeProduto: string,
  codigoPdv: number,
  desfecho: "confirmado" | "cancelado",
  motivo?: string
): Promise<void> {
  try {
    await fetch("/api/notificar-desfecho", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lojaId, nomeProduto, codigoPdv, desfecho, motivo }),
    });
  } catch (erro) {
    console.warn("Falha ao notificar desfecho à filial:", erro);
  }
}

export async function avisarDesfechoSuprimentos(
  lojaId: string,
  desfecho: "confirmado" | "cancelado",
  motivo?: string
): Promise<void> {
  try {
    await fetch("/api/notificar-desfecho-suprimentos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lojaId, desfecho, motivo }),
    });
  } catch (erro) {
    console.warn("Falha ao notificar desfecho de suprimentos à filial:", erro);
  }
}

export async function avisarListaAjustada(lojaId: string, diferencas: number): Promise<void> {
  try {
    await fetch("/api/notificar-ajuste", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lojaId, diferencas }),
    });
  } catch (erro) {
    console.warn("Falha ao notificar ajuste à filial:", erro);
  }
}

export function explicarFalhaDeEnvio(motivo: string): string {
  if (motivo.includes("token")) return "aparelho sem registro de push";
  if (motivo.includes("network")) return "sem conexão";
  return motivo;
}