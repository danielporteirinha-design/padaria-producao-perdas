/**
 * src/types/suprimento.ts
 * ---------------------------------------------------------------
 * Tipos e utilitários para a lista de suprimentos (embalagens e
 * material de limpeza) pedida pelas filiais à matriz (ago/2026).
 */

export interface Suprimento {
  id: string;
  nome: string;
  segmento: string;
  ativo: boolean;
  criadoPor: string;
  criadoEm: string;
}

export interface ItemPedidoSuprimento {
  suprimentoId: string;
  quantidade: number;
}

export interface AtendimentoSuprimento {
  desfecho: "confirmado" | "cancelado";
  por: string;
  em: string;
  motivo?: string;
}

export interface PedidoSuprimentos {
  id: string;
  lojaId: string;
  data: string;
  itens: ItemPedidoSuprimento[];
  status: "rascunho" | "enviado";
  atendimento?: AtendimentoSuprimento;
  criadoPor: string;
  criadoEm: string;
  enviadoEm?: string;
}

export const SEGMENTOS_SUPRIMENTO: { chave: string; rotulo: string }[] = [
  { chave: "embalagens", rotulo: "Embalagens" },
  { chave: "sacolas", rotulo: "Sacolas" },
  { chave: "limpeza", rotulo: "Material de Limpeza" },
];

export function idDoSuprimento(nome: string): string {
  return nome
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function idDoPedidoSuprimentos(data: string, lojaId: string): string {
  return `suprimentos-${data}-${lojaId}`;
}

export function variedadesDoPedidoSuprimentos(pedido: PedidoSuprimentos | undefined): number {
  return pedido?.itens.length ?? 0;
}

export function desfechoDosSuprimentos(pedido: PedidoSuprimentos | undefined): "pendente" | "confirmado" | "cancelado" {
  if (!pedido || pedido.status !== "enviado") return "pendente";
  if (!pedido.atendimento) return "pendente";
  return pedido.atendimento.desfecho;
}

export function agruparPorSegmento(
  itens: ItemPedidoSuprimento[],
  catalogo: Suprimento[]
): { chave: string; rotulo: string; itens: { nome: string; quantidade: number }[] }[] {
  const mapaCatalogo = new Map(catalogo.map((s) => [s.id, s]));

  const gruposMap = new Map<string, { nome: string; quantidade: number }[]>();
  for (const seg of SEGMENTOS_SUPRIMENTO) {
    gruposMap.set(seg.chave, []);
  }

  for (const item of itens) {
    const sup = mapaCatalogo.get(item.suprimentoId);
    const segmentoChave = sup?.segmento ?? "embalagens";
    const nome = sup?.nome ?? item.suprimentoId;

    const lista = gruposMap.get(segmentoChave) ?? [];
    lista.push({ nome, quantidade: item.quantidade });
    gruposMap.set(segmentoChave, lista);
  }

  return SEGMENTOS_SUPRIMENTO.map((seg) => ({
    chave: seg.chave,
    rotulo: seg.rotulo,
    itens: gruposMap.get(seg.chave) ?? [],
  })).filter((g) => g.itens.length > 0);
}